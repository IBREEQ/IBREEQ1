IBREEQ - Cloudflare Pages + Functions + D1

1) Upload the contents of this ZIP to GitHub repository IBREEQ1.
   The important structure is:
   index.html
   logo.jpeg
   functions/_utils.js
   functions/api/config.js
   functions/api/applications.js
   functions/api/admin/login.js
   functions/api/admin/applications.js
   functions/api/admin/fields.js
   functions/api/admin/applications/[id].js

2) In Cloudflare Pages, connect the IBREEQ1 GitHub repository.
   Build command: leave empty.
   Build output directory: leave empty / root.

3) Create a D1 database in Cloudflare.
   In the Pages project: Settings > Functions > Bindings > Add D1 database.
   Binding name MUST be: DB

4) Optional but recommended: add an environment variable/secret:
   ADMIN_CODE = .IBREEQ11
   If omitted, the site defaults to .IBREEQ11.

The Functions automatically create the D1 tables on first request, so you do not need to run schema.sql manually.

The site uses the existing /api/... URLs from the original front-end, but now saves applications centrally in D1, so submissions from other phones can appear in the admin dashboard.
