
import { ensureSchema, getFields, json } from "../_utils.js";
export async function onRequestGet({ env }) {
  await ensureSchema(env.DB);
  return json({ fields: await getFields(env.DB) });
}
