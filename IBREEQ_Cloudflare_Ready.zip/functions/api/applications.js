
import { ensureSchema, getFields, json } from "../_utils.js";
export async function onRequestPost({ request, env }) {
  await ensureSchema(env.DB);
  const fields = await getFields(env.DB);
  let body = {};
  try { body = await request.json(); } catch {}
  const values = body?.values || {};
  const missing = fields.filter(f => f.required && !String(values[f.id] ?? '').trim());
  if (missing.length) return json({ error: `يرجى تعبئة: ${missing.map(f=>f.label).join('، ')}` }, 400);

  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  const cleanValues = Object.fromEntries(fields.map(f => [f.id, String(values[f.id] ?? '').trim()]));
  await env.DB.prepare(
    "INSERT INTO applications (id,created_at,values_json) VALUES (?,?,?)"
  ).bind(id, createdAt, JSON.stringify(cleanValues)).run();

  return json({ ok:true, id });
}
