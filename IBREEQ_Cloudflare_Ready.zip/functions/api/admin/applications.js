
import { ensureSchema, getFields, json, adminOk } from "../../_utils.js";
export async function onRequestGet({ request, env }) {
  if (!adminOk(request, env)) return json({error:'رمز لوحة الإدارة غير صحيح'},401);
  await ensureSchema(env.DB);
  const rows = await env.DB.prepare("SELECT id,created_at,values_json FROM applications ORDER BY created_at DESC").all();
  const applications = (rows.results || []).map(r => ({
    id:r.id, createdAt:r.created_at, values:JSON.parse(r.values_json)
  }));
  return json({applications, fields:await getFields(env.DB)});
}
