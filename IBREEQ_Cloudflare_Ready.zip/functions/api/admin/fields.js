
import { ensureSchema, getFields, json, adminOk, cleanField } from "../../_utils.js";
export async function onRequestPut({ request, env }) {
  if (!adminOk(request, env)) return json({error:'رمز لوحة الإدارة غير صحيح'},401);
  await ensureSchema(env.DB);
  let body = {};
  try { body = await request.json(); } catch {}
  if (!Array.isArray(body?.fields)) return json({error:'بيانات الحقول غير صحيحة'},400);
  const fields = body.fields.map(cleanField);
  await env.DB.prepare("INSERT INTO settings (key,value) VALUES ('fields',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")
    .bind(JSON.stringify(fields)).run();
  return json({ok:true,fields});
}
