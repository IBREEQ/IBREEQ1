
import { json, adminOk } from "../../../_utils.js";
export async function onRequestDelete({ request, env, params }) {
  if (!adminOk(request, env)) return json({error:'رمز لوحة الإدارة غير صحيح'},401);
  await env.DB.prepare("DELETE FROM applications WHERE id=?").bind(params.id).run();
  return json({ok:true});
}
