
import { json } from "../../_utils.js";
export async function onRequestPost({ request, env }) {
  let body = {};
  try { body = await request.json(); } catch {}
  const ok = body?.code === (env.ADMIN_CODE || '.IBREEQ11');
  return ok ? json({ok:true}) : json({error:'الرمز غير صحيح'},401);
}
