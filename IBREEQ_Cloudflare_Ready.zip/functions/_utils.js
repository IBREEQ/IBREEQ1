
export async function ensureSchema(db) {
  await db.prepare(`CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  )`).run();
  await db.prepare(`CREATE TABLE IF NOT EXISTS applications (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    values_json TEXT NOT NULL
  )`).run();

  const row = await db.prepare("SELECT value FROM settings WHERE key = 'fields'").first();
  if (!row) {
    const fields = [
      { id:'name', label:'الاسم الكامل', type:'text', required:true, placeholder:'مثال: أحمد محمد' },
      { id:'phone', label:'رقم الهاتف', type:'tel', required:true, placeholder:'مثال: 99XXXXXX' },
      { id:'email', label:'البريد الإلكتروني', type:'email', required:true, placeholder:'مثال: name@email.com' },
      { id:'position', label:'الوظيفة المطلوبة', type:'select', required:true, options:['موظف استقبال','خدمة عملاء','مبيعات','محاسب','موظف إداري','أخرى'], placeholder:'اختر الوظيفة' },
      { id:'experience', label:'الخبرة السابقة', type:'textarea', required:false, placeholder:'اكتب نبذة مختصرة عن خبرتك...' },
      { id:'education', label:'المؤهل الدراسي', type:'text', required:true, placeholder:'مثال: دبلوم / بكالوريوس' },
      { id:'notes', label:'ملاحظات إضافية', type:'textarea', required:false, placeholder:'أي معلومات إضافية تود ذكرها...' }
    ];
    await db.prepare("INSERT INTO settings (key,value) VALUES ('fields',?)")
      .bind(JSON.stringify(fields)).run();
  }
}
export async function getFields(db) {
  const row = await db.prepare("SELECT value FROM settings WHERE key='fields'").first();
  return row ? JSON.parse(row.value) : [];
}
export function json(data, status=200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {'content-type':'application/json; charset=utf-8'}
  });
}
export function adminOk(request, env) {
  const code = request.headers.get('x-admin-code') || '';
  return code === (env.ADMIN_CODE || '.IBREEQ11');
}
export function cleanField(field) {
  return {
    id: String(field.id || crypto.randomUUID()),
    label: String(field.label || 'حقل جديد').slice(0,100),
    type: ['text','tel','email','textarea','select'].includes(field.type) ? field.type : 'text',
    required: !!field.required,
    placeholder: String(field.placeholder || '').slice(0,160),
    options: Array.isArray(field.options) ? field.options.map(x=>String(x).slice(0,80)).filter(Boolean).slice(0,30) : []
  };
}
